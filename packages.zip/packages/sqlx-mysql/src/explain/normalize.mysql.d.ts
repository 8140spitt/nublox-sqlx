export declare function explainNormalized(exec: (sql: string) => Promise<{
    rows: any[];
}>, q: string): Promise<any>;
